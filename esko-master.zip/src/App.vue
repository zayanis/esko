<template>
    <div>

		<transition name="fade" mode="out-in" appear>
            <keep-alive>
                <app-login v-if="!isAuthenticated"></app-login>
                 <app-dashboard></app-dashboard>
            </keep-alive>
        </transition>

    </div>
</template>

<script>
import { mapGetters } from 'vuex';
import dashboard from './components/Dashboard.vue';
import login from './components/Login.vue';


export default {
    components: {
        'app-accueil': dashboard,
		'app-login': login
 
    },
data() {
        return {
            isAuthenticated: false
        }
    },
    computed: {
        ...mapGetters({
        })
    },
    methods: {
	        onSuccessfulLogin(authToken) {
            localStorage.setItem('authToken', authToken);
           // this.$store.commit('setIsAuthenticated', true);
        }
    },
    created() {
           const authToken = localStorage.getItem('authToken');

        if (authToken !== null) {
            this.onSuccessfulLogin(authToken);
        }
    }
}
</script>
