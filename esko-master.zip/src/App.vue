<template>
    <div>
		
                <app-accueil></app-accueil>

    </div>
</template>

<script>
import { mapGetters } from 'vuex';
import accueil from './components/Dashboard.vue'


export default {
    components: {
        'app-accueil': accueil,
	
        
    },
    computed: {
        ...mapGetters({
        })
    },
    methods: {
    },
    created() {
       
    }
}
</script>
