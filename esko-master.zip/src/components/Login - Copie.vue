<template>
<div>

<br></br><br></br><br></br><br></br><br></br><br></br><br></br>
<div class="ui middle aligned ">

    <div class="column">
        <div class="ui center aligned page grid">
            <div class="eight wide  column">
                <div class="ui left aligned segment">
               

                    <div class="ui form">
                        <div class="field">
                            <label for="username">E-mail:</label>
                            <div class="ui icon input">
                                <input type="text" placeholder="Username" name="E-mail" id="username" v-model="username" /> <i class="user icon"></i>

                            </div>
                        </div>
                        <div class="field">
                            <label for="password">Mot de passe:</label>
                            <div class="ui icon input">
                                <input type="password" placeholder="Mot de passe" name="password" id="password" v-model="password"/> <i class="lock icon"></i>

                            </div>
                        </div>
                        <input type="submit" name="submit" @click="onLoginButtonClick" class="ui inverted blue button" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</template>

<script>
import lodashStartCase from 'lodash/startCase';

export default {
    data() {
        return {
            error: null,
            username: null,
            password: null
        }
    },
    methods: {
        onLoginButtonClick() {
            this.$http.post('login', {
                username: this.username,
                password: this.password
            }).then(response => {
                this.error = this.username = this.password = null;
                this.$emit('loggedIn', response.body.authToken);
            }, error => {
                this.error = error.body;
            });
        }
    },
    filters: {
        startCase(value) {
            return lodashStartCase(value);
        }
    },
}
</script>
