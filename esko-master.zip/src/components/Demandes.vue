<template>
<div>
<p><h1>text</h1></p>
<div class="ui top attached tabular menu">
  <div class="item"></div>
</div>
<div class="ui bottom attached tab segment">
  <p></p>
  <p></p>
  <p></p>
</div>
<p></p>



<div class="ui secondary  menu" >

	<div class="item">
		<semantic-ui-dropdown
                            :selection="true"
                            :fluid="true"
                            text="De"
                            :items="pays"
                            v-model="paysfrom"
		></semantic-ui-dropdown>
	</div>

					
   <div class="item">

		<semantic-ui-dropdown
                            :selection="true"
                            :fluid="true"
                            text="Vers"
                            :items="pays"
                            v-model="paysdest"
                    ></semantic-ui-dropdown>

		</div>		
		

  <div class="right menu">
    <div class="item">
      <div>
		<button v-on:click="rechercher();" class="ui primary button">Rechercher</button>
        </div>  
	</div>
  </div>

  </div>



	   
 <table class="ui red table sortable">
  <thead>
    <tr>
    <th>De</th>
    <th>Vers</th>
	<th>Montant</th>
	<th>Devise</th>
	<th>Taux</th>
	<th>Date</th>
	<th></th>
  </tr>
  </thead>
  
  <tbody>
  
   <tr v-if="demandes.length > 0" v-for="demande in demandes">
                   
                    <td>{{ demande.FROM }}</td>
                    <td>{{ demande.DEST }}</td>
					<td>{{ demande.MONTANT }}</td>
                    <td>{{ demande.DEVISE }}</td>
                    <td>{{ demande.TAUX }}</td>
					<td>{{ demande.DATE }}</td>
					<td class="selectable"><a href="#/demandes" @click="onDetailUser(demande)"><i class="unhide icon"></i></a></td>
                    
	</tr>


    </tbody>
	
	 <tfoot>
    <tr>
    
  <th><div class="ui red basic label" v-if="demandes.length < 1">Aucune demande trouv�e</div></th>
  <th colspan="7">
		<div class="ui right floated small primary labeled icon button">
		<button v-on:click="afficherAjoutDemande();" class="ui primary button">Ajouter une demande</button>
        </div>
		
      </th>
    </tr>
  </tfoot>
</table>
   
    
         
		  <semantic-ui-modal v-if="shouldShowModal" :active="true" @hidden="onModalClose" >
            <template slot="header" >

				<div class="ui middle aligned center aligned grid">

				<div class="column">
					<div class="ui center aligned page grid">
						<div class="column">
							<div class="ui left aligned segment">
						   

								<div class="ui form">
									<div class="field">
										<label for="mail">E-mail:</label>
										<div class="ui icon input">
											<input type="text" placeholder="mail" name="E-mail" id="mail" v-bind:value=this.selectedDemande.user[0].mail disabled /> <i class="mail icon"></i>

										</div>
									</div>
									<div class="field">
										<label for="telephone">Tel:</label>
										<div class="ui icon input">
											<input type="text" placeholder="Mot de passe" name="telephone" id="telephone"  v-bind:value=this.selectedDemande.user[0].telephone disabled /> <i class="call icon"></i>

										</div>
									</div>
									  <div class="field">
										<label for="adresse">Adresse:</label>
										<div class="ui icon input">
											<input type="text"   name="adresse" id="adresse"  v-bind:value=this.selectedDemande.user[0].adresse disabled /> <i class="location arrow icon"></i>

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

            </template>
           
        </semantic-ui-modal>
  



		  <semantic-ui-modal v-if="shouldShowAddDemand" :active="true" @hidden="onModalClose" >
            <template slot="header" >
    
					
					     <form class="ui form" >
					   <li>{{ error }}</li>
								  <div class="field">
									<semantic-ui-dropdown
														:selection="true"
														:fluid="true"
														text="De"
														:items="pays"
														v-model="demandeFrom"
									></semantic-ui-dropdown>
								</div>

									
					  <div class="field">

						<semantic-ui-dropdown
											:selection="true"
											:fluid="true"
											text="Vers"
											:items="pays"
											v-model="demandeDest"
									></semantic-ui-dropdown>

					</div>		
						
				  <div class="field">
						<div class="ui input focus">
							<input type="number" placeholder="Montant" v-model="montant">
						</div>
					</div>	
				  <div class="field">
						<div class="ui input focus">
							<input type="number" placeholder="Taux"  v-model="taux">
						</div>
					</div>	
				
									
						  <div class="field">
								<div class="ui input focus">
									<input type="text" placeholder="Devise" v-bind:value=this.devise disabled>
								</div>
					</div>	
					
	
					
				  <div class="field">
						<div class="ui input focus">
							<input type="date" placeholder="Date" v-model="date">
						</div>
					</div>						
			
			
									
				
					  <div class="field">
						  <div>
							<button v-on:click="ajouterDemande();" class="ui primary button">Ajouter</button>
							</div>  
						</div>
				

				</form>
	

	
	
            </template>
           
        </semantic-ui-modal>
	


	
	     <div class="ui active inverted dimmer" v-if="loader"><div class="ui text loader"></div></div>
  </div>


</template>

<script>
import { mapGetters, mapMutations } from 'vuex';
import { Dropdown, Modal } from 'semantic-ui-vue2';


export default {
components: {
        'semantic-ui-dropdown': Dropdown,
           'semantic-ui-modal': Modal
    },
data() {
        return {
            show: false,
            selected: '',
			paysfrom :'',
			paysdest :'',
			demandeDest :'',
			demandeFrom :'',
			montant :0,
			date :'',
			loader: false,
			taux: 0,
			devise: '',
            selectedDemande: null,
			  shouldShowModal: false,
			  shouldShowAddDemand: false,
			  error: ''
        }
    },
    computed: {
        ...mapGetters({
		  pays: 'getPays',
		  demandes: 'getAllDemandes',
		    inscrit: 'getInscrit'
        })
    },
	mounted() {

			this.$store.dispatch('requestPays');
	
    },
	
	
    methods: {
	 			
        rechercher() {
	
		
			if(this.paysfrom &&  this.paysdest ){
				this.loader= true;
			var request = '{"FROM":"' +this.paysfrom+ '", "DEST": "' + this.paysdest +'"}';
			           this.$store.dispatch('requestDemandesByPays',request);
			}
        },
        onModalClose() {

			var a = this.shouldShowAddDemand;
            this.shouldShowModal = false;
			 this.shouldShowAddDemand = false;
			this.selectedDemande=null;
			if(a){
			this.rechercher();
			a=false;
			}
			
        }, 
		onDetailUser(demande) {
		this.selectedDemande=demande;
            this.shouldShowModal = true;
			

        },
	afficherAjoutDemande() {
		
            this.shouldShowAddDemand = true;
			

        },
		
		
		ajouterDemande(){
			
		if( this.demandeFrom == null || this.demandeFrom == "" ){
							this.error="Champs De manquants";
								return false;
						}
						else if( this.demandeDest == null || this.demandeDest == "" ){
							this.error="Champs Vers manquant";
						}
						else if( this.devise == null || this.devise == "" ){
							this.error="Champs devise manquant";
						}
						else if( this.montant == null || this.montant == "" ){
							this.error="Champs motant manquant";
						}
						else if( this.taux == null || this.taux == "" ){
							this.error="Champs taux manquant";
						}
						else if( this.date == null || this.date == "" ){
							this.error="Champs date manquant";
						}
						else{
						this.error="";
	
		
			 this.$http.post('https://eskodb-f2a5.restdb.io/rest/demandes',   {
									FROM: this.demandeFrom,
									DEST: this.demandeDest,
									DEVISE: this.devise,
									MONTANT: this.montant,
									TAUX: this.taux,
									DATE: this.date,
									user: this.inscrit
			 
			 })
			 .then(response => {
                this.demandeFrom = '';
                this.demandeDest = '';
				this.devise='',
				this.montant=0;
				this.taux=0;
				this.date='';
				 this.shouldShowAddDemand = false;
            });
			}	
		},
		
		
    },
	 created() {
      if( this.inscrit == null || this.inscrit == "" ){
	  var username= localStorage.getItem('authToken');
	  var request = '{"mail":"' +username +'"}';
	  			this.$store.dispatch('requestInscrit',request);
		
	  }
    },
	watch: {
        paysfrom(pays) {
		 this.paysfrom=pays;
        },
		 paysdest(pays) {
			this.paysdest=pays;
        },
		 demandes(demandes) {
			this.loader= false;
        },
		 demandeDest(pays) {
					for (let i in this.pays) {
						if( this.pays[i].value == pays){
								this.devise=this.pays[i].devise;
							}
					}
        }
		
    },
	

}
</script>