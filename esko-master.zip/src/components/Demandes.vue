<template>
    <div>
        
                <app-recherche></app-recherche>
    </div>
</template>

<script>
import { mapGetters } from 'vuex';
import Recherche from './Demandes/RechercheDemandes.vue';

export default {
    components: {
        'app-recherche': Recherche
    },
    computed: {
        ...mapGetters({
        })
    },
    methods: {
       
    },
    created() {
	
     
    }
}
</script>

