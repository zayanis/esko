<template>
<div>
  
<button @click="authenticate('facebook')">auth Facebook</button>
<button @click="authenticate('google')">auth Google</button>

 </div>
</template>
 
 
 
<script>
import VueAuthenticate from 'vue-authenticate';
import { Dropdown, Modal } from 'semantic-ui-vue2';



export default {
components: {
        'vueAuth': VueAuthenticate,
           'semantic-ui-modal': Modal
    },
  data () {
    return {
    }
  },
  methods: {

   

	   authenticate(provider) {
        this.$http.get('https://www.googleapis.com/plus/v1/people/me/openIdConnect',    {headers: {'x-apikey':'5a50e16e7679b5244b6632d4'}})
		.then(response => {
         alert('i');
        });
		

	  
    },
    onSignInError (error) {
      // `error` contains any error occurred. 
      console.log('OH NOES', error)
    }
  }
}
</script> 