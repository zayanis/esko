<template>


<div>R  {{paysfrom}}   test</div>
 
 
 

</template>

<script>
import { mapGetters, mapMutations } from 'vuex';
import { Dropdown } from 'semantic-ui-vue2';


export default {

components: {

        'semantic-ui-dropdown': Dropdown
    },
data() {
        return {
            show: '',
            selected: '',
			paysfrom :'',
			paysdest :'',
			montant :0,
			date :null,
			
            selectedFood: null
        }
    },
    computed: {
        ...mapGetters({
        })
    },
    methods: {
    },
	
    created() {
	this.paysfrom=this.$route.query.paysfrom; 
	this.paysdest=this.$route.query.paysdest; 

	this.$store.dispatch('requestDemandesByPays',this.paysfrom,this.paysdest);
	
    }
	 
}
</script>

