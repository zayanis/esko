<template>
 
 
<form class="ui form" v-on:submit="submitData"  method="get">
  <div>
    <div class="field">
      <label>Envoyer de</label>
		<select class="ui fluid search selection dropdown" v-model="paysfrom">
			<option v-for="option in options" v-bind:value="option.value">
				{{ option.text }}
			</option>
		</select>
    </div>
	  <div class="field">
      <label>Envoyer vers</label>
		<select class="ui fluid search selection dropdown" v-model="paysdest">
			<option v-for="option in options" v-bind:value="option.value">
				{{ option.text }}
			</option>
		</select>
    </div>

   <button class="ui button" type="submit">Rechercher</button>
</div>
  
  </form>
 
 
 

</template>

<script>
import { mapGetters, mapMutations } from 'vuex';
import { Dropdown } from 'semantic-ui-vue2';

export default {
components: {
        'semantic-ui-dropdown': Dropdown
    },
data() {
        return {
            show: false,
            selected: '',
			paysfrom :'',
			paysdest :'',
			montant :0,
			date :null,
			
            selectedFood: null
        }
    },
    computed: {
        ...mapGetters({
		  options: 'getOptions'
        })
    },
	
    methods: {
	  submitData: function() {
			this.$router.push({ path: 'resultatsdemandes', query: {paysfrom: this.paysfrom, paysdest: this.paysdest}});
			// this.$router.push('/resultatsdemandes?paysfrom=xxxaaxxx');
			}
    },
	
    created() {


    }

}
</script>

