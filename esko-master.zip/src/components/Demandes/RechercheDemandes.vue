<template>
<div>

<div class="ui top attached tabular menu">
  <div class="item"></div>
</div>
<div class="ui bottom attached tab segment">
  <p></p>
  <p></p>
  <p></p>
</div>
<p></p>



<div class="ui secondary  menu" >

	<div class="item">
		<semantic-ui-dropdown
                            :selection="true"
                            :fluid="true"
                            text="De"
                            :items="options"
                            v-model="paysfrom"
		></semantic-ui-dropdown>
	</div>

					
   <div class="item">

		<semantic-ui-dropdown
                            :selection="true"
                            :fluid="true"
                            text="Vers"
                            :items="options"
                            v-model="paysdest"
                    ></semantic-ui-dropdown>

		</div>		
		

  <div class="right menu">
    <div class="item">
      <div>
		<button v-on:click="rechercher();" class="ui primary button">Rechercher</button>
        </div>  
	</div>
  </div>

  </div>



	   
 <table class="ui red table sortable">
  <thead>
    <tr>
    <th>De</th>
    <th>Vers</th>
	<th>Montant</th>
	<th>Devise</th>
	<th>Taux</th>
	<th>Date</th>
	<th></th>
  </tr>
  </thead>
  
  <tbody>
  
   <tr v-if="demandes.length > 0" v-for="demande in demandes">
                   
                    <td>{{ demande.FROM }}</td>
                    <td>{{ demande.DEST }}</td>
					<td>{{ demande.MONTANT }}</td>
                    <td>{{ demande.DEVISE }}</td>
                    <td>{{ demande.TAUX }}</td>
					<td>{{ demande.DATE }}</td>
					<td class="selectable"><a href="#/demandes" @click="onDetailUser(demande)"><i class="unhide icon"></i></a></td>
                    
	</tr>


    </tbody>
	
	 <tfoot>
    <tr>
    
  <th><div class="ui red basic label" v-if="demandes.length < 1">Aucune Resultat</div></th>
  <th colspan="7">
		<div class="ui right floated small primary labeled icon button">
		<button v-on:click="afficher();" class="ui primary button">Ajouter une demande</button>
        </div>
		
      </th>
    </tr>
  </tfoot>
</table>
   
    
         
		  <semantic-ui-modal v-if="shouldShowModal" :active="true" @hidden="onModalClose" >
            <template slot="header" >
                <i class="book icon"></i>
                <p>Contact</p> {{this.selectedDemande.DATE}}
				<p>telephone</p>{{this.selectedDemande.user[0].telephone}}
				<p>email</p>{{this.selectedDemande.user[0].email}}
            </template>
           
        </semantic-ui-modal>
  



		  <semantic-ui-modal v-if="shouldShowAddDemand" :active="true" @hidden="onModalClose" >
            <template slot="header" >
    
					
					     <form class="ui form" @submit.prevent.stop="handleFormSubmission">

								  <div class="field">
									<semantic-ui-dropdown
														:selection="true"
														:fluid="true"
														text="De"
														:items="options"
														v-model="demandeFrom"
									></semantic-ui-dropdown>
								</div>

									
					  <div class="field">

						<semantic-ui-dropdown
											:selection="true"
											:fluid="true"
											text="Vers"
											:items="options"
											v-model="demandeDest"
									></semantic-ui-dropdown>

					</div>		
						
				  <div class="field">
						<div class="ui input focus">
							<input type="number" placeholder="Montant">
						</div>
					</div>	
				  <div class="field">
						<div class="ui input focus">
							<input type="number" placeholder="Taux" >
						</div>
					</div>	
				
									
						  <div class="field">
								<div class="ui input focus">
									<input type="text" placeholder="Devise" v-bind:value=this.devise disabled>
								</div>
					</div>	
					
	
					
				  <div class="field">
						<div class="ui input focus">
							<input type="date" placeholder="Date">
						</div>
					</div>						
			
			
									
				
					  <div class="field">
						  <div>
							<button v-on:click="ajouterDeamnde();" class="ui primary button">Ajouter</button>
							</div>  
						</div>
				

				</form>
	
	
	
	
	
	
	
	
	
	
            </template>
           
        </semantic-ui-modal>
	


	
	     <div class="ui active inverted dimmer" v-if="loader"><div class="ui text loader"></div></div>
  </div>


</template>

<script>
import { mapGetters, mapMutations } from 'vuex';
import { Dropdown, Modal } from 'semantic-ui-vue2';


export default {
components: {
        'semantic-ui-dropdown': Dropdown,
           'semantic-ui-modal': Modal
    },
data() {
        return {
            show: false,
            selected: '',
			paysfrom :'',
			paysdest :'',
			demandeDest :'',
			demandeFrom :'',
			montant :0,
			date :null,
			loader: false,
			devise: '',
            selectedDemande: null,
			  shouldShowModal: false,
			  shouldShowAddDemand: false
        }
    },
    computed: {
        ...mapGetters({
		  options: 'getOptions',
		  demandes: 'getAllDemandes'
        })
    },
	
    methods: {
	  submitData: function() {
			this.$router.push({ path: 'demandes', query: {paysfrom: this.paysfrom, paysdest: this.paysdest}});
			// this.$router.push('/resultatsdemandes?paysfrom=xxxaaxxx');
			},
			
        rechercher() {
	
		
			if(this.paysfrom &&  this.paysdest ){
				this.loader= true;
			var request = '{"FROM":"' +this.paysfrom+ '", "DEST": "' + this.paysdest +'"}';
			           this.$store.dispatch('requestDemandesByPays',request);
			}
			else{
			
			}

		
		
        },
        onModalClose() {

            this.shouldShowModal = false;
			 this.shouldShowAddDemand = false;
			this.selectedDemande=null;
        }, 
		onDetailUser(demande) {

            this.shouldShowModal = true;
			this.selectedDemande=demande;

        },
		afficher() {
					 this.shouldShowAddDemand = true;

        },
		
		
		
    },
	watch: {
        paysfrom(pays) {
		 this.paysfrom=pays;
        },
		 paysdest(pays) {
			this.paysdest=pays;
        },
		 demandes(demandes) {
			this.loader= false;
        },
		 demandeDest(pays) {
					for (let i in this.options) {
						if( this.options[i].value == pays){
								this.devise=this.options[i].devise;
							}
					}
        }
    },
	

}
</script>

