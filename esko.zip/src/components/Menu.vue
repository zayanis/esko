<template>
    <div>
        <div class="ui  container">
		<div class="ui secondary pointing menu">
				  <a class="item">
					  <router-link to="/profile" class="item" active-class="active">
                            Profile
                        </router-link>
				  </a>
				  <a class="item">
					   <router-link to="/demandes" class="item" active-class="active">
                            Demandes
                        </router-link>
				  </a>
				  <a class="item">
					      <router-link to="/taux" class="item" active-class="active">
                            Taux
                        </router-link>
				  </a>
			  <div class="ui right item">
				 <a class="item" @click="onLogoutClicked">
				 <router-link to="/login" class="item" active-class="active">
                      Logout
                        </router-link>
						</a>
			  </div>
	
		
		</div>
		
		
           
    </div>
	

	   </div>
</template>

<script>

import { mapGetters, mapMutations } from 'vuex';

export default {

data() {
        return {
          isAuthenticated: false
        }
    },
	 beforeCreate: function (){
	
	 },
    mounted() {

	
	if (this.$session.exists()) {
		this.isAuthenticated = true;
	  }
	  		this.$forceUpdate();
    },
	 
    methods: {
        onLogoutClicked() {
			this.$session.destroy();
			localStorage.removeItem('authToken');
            this.$store.commit('setisAuthenticated', false);
			
        }
    }
}
</script>
